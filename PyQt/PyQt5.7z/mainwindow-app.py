# -*- coding: utf-8 -*-

# Form implementation generated from reading ui file 'mainwindow.ui'
#
# Created by: PyQt5 UI code generator 5.11.3
#
# WARNING! All changes made in this file will be lost!
import os
import sys
import cv2
import shutil
import platform

from PyQt5 import QtCore, QtGui, QtWidgets
from Ui_MainWindow import Ui_MainWindow

class UI(Ui_MainWindow):
    def __init__(self, MainWindow):
        self.setupUi(MainWindow)
        self.connect_action()

    def connect_action(self):
        self.ImageFolderBtn.clicked.connect(self.imagefolderBtn_func)
        self.RightFolderBtn.clicked.connect(self.RightFolderBtn_func)
        self.DeleteFolerBtn.clicked.connect(self.DeleteFolerBtn_func)
        self.KeepBtn.clicked.connect(self.KeepBtn_func)
        self.DeleteBtn.clicked.connect(self.DeleteBtn_func)

    def filter_file(self, filelist, filters):
        if not len(filelist):
            return None
        i = 0
        imagefile = filelist[i]
        while imagefile:
            if not os.path.splitext(imagefile)[1] in filters:
                filelist.pop(i)
            else:
                i = i + 1
            if i < len(filelist):
                imagefile = filelist[i]
            else:
                imagefile = None

    def getimagefile(self):
        if len(self.imagefilelist):
            return self.imagefilelist.pop(0)
        else:
            return None

    def showimage(self, image):
        img_origin = cv2.imread(os.path.join(self.imagefolder_var,
                                             image))  #读取图像
        img_origin = cv2.cvtColor(img_origin, cv2.COLOR_BGR2RGB)  #转换图像通道
        img = cv2.resize(img_origin, (760, 760), cv2.INTER_LINEAR)
        x = img.shape[1]  #获取图像大小
        y = img.shape[0]
        # self.zoomscale = 1  #图片放缩尺度
        frame = QtGui.QImage(img, x, y, QtGui.QImage.Format_RGB888)
        pix = QtGui.QPixmap.fromImage(frame)
        self.item = QtWidgets.QGraphicsPixmapItem(pix)  #创建像素图元
        #self.item.setScale(self.zoomscale)
        self.scene = QtWidgets.QGraphicsScene()  #创建场景
        self.scene.addItem(self.item)
        self.graphicsView.setScene(self.scene)  #将场景添加至视图

    def next_image(self):
        self.cur_image = self.getimagefile()
        if self.cur_image:
            self.imageinfoText.setText(
                str(len(self.imagefilelist) + 1) + '\t' + self.cur_image)
            self.showimage(self.cur_image)
        else:
            self.imageinfoText.setText("No Images.")

    def imagefolderBtn_func(self):
        if str(platform.system()) == 'Windows' and os.path.exists('D:/data'):
            cur_path = 'D:/data/'
        self.imagefolder_var = QtWidgets.QFileDialog.getExistingDirectory(
            None, 'Choose image folder', cur_path)
        if not self.imagefolder_var:
            return False
        self.ImageFolerText.setText(self.imagefolder_var)
        self.imagefilelist = os.listdir(self.imagefolder_var)
        self.filter_file(self.imagefilelist, ['.jpg', '.gif', '.png', '.tif'])
        self.next_image()

    def RightFolderBtn_func(self):
        cur_path = ''
        if hasattr(self, 'imagefolder_var'):
            cur_path = self.imagefolder_var
        else:
            cur_path = os.getcwd()
        self.RightFolder_var = QtWidgets.QFileDialog.getExistingDirectory(
            None, 'Choose save right image folder', cur_path)
        self.RightFolerText.setText(self.RightFolder_var)

    def DeleteFolerBtn_func(self):
        cur_path = ''
        if hasattr(self, 'imagefolder_var'):
            cur_path = self.imagefolder_var
        else:
            cur_path = os.getcwd()
        self.DeleteFoler_var = QtWidgets.QFileDialog.getExistingDirectory(
            None, 'Choose save not qualified image folder', cur_path)
        self.DeleteFolerText.setText(self.DeleteFoler_var)

    def KeepBtn_func(self):
        if not self.cur_image:
            return None
        shutil.move(
            os.path.join(self.imagefolder_var, self.cur_image),
            self.RightFolder_var)
        self.next_image()

    def DeleteBtn_func(self):
        if not self.cur_image:
            return None
        shutil.move(
            os.path.join(self.imagefolder_var, self.cur_image),
            self.DeleteFoler_var)
        self.next_image()


if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    form = QtWidgets.QMainWindow()
    widgetee = UI(form)
    form.show()
    sys.exit(app.exec_())